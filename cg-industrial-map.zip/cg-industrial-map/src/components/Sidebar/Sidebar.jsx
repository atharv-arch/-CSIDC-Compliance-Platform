function Sidebar() {
  return (
    <div
      style={{
        width: "300px",
        background: "#111",
        color: "white",
        padding: "20px",
      }}
    >
      <h2>CG Industrial Map</h2>
      <p>Phase 1 Base Layout</p>
    </div>
  );
}

export default Sidebar;
